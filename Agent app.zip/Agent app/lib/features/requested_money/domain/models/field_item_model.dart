class FieldItemModel{
  final String key;
  final String value;
  FieldItemModel(this.key, this.value);

}