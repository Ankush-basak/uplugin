enum NavbarType {
  homeScreen,
  transactionHistoryScreen,
  notificationScreen,
  profileScreen,
}