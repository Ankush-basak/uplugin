class TransactionType{
  static const String  sendMoney = 'send_money';
  static const String  addMoney = 'addMoney';
  static const String  requestMoney= 'requestMoney';
  static const String  withdrawRequest = 'withdraw_request';
}