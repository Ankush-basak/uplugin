
enum RequestType {
  sendRequest,
  withdraw
}