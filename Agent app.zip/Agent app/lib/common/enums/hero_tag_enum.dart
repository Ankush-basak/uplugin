enum HeroTag{
  qrCode,
}